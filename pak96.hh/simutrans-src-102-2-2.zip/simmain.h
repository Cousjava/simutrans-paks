#ifndef SIMMAIN_H
#define SIMMAIN_H


int simu_main(int argc, char** argv);

#endif
