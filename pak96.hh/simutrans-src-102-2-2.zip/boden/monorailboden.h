#ifndef monorailboden_h
#define monorailboden_h

#include "grund.h"

class monorailboden_t : public grund_t
{
protected:
	void calc_bild_internal();

public:
	monorailboden_t(karte_t *welt, loadsave_t *file, koord pos ) : grund_t( welt, koord3d(pos,0) ) { rdwr(file); }
	monorailboden_t(karte_t *welt, koord3d pos,hang_t::typ slope);

	virtual void rdwr(loadsave_t *file);

	const char *get_name() const {return "Monorailboden";}
	enum grund_t::typ get_typ() const {return monorailboden;}
};

#endif
