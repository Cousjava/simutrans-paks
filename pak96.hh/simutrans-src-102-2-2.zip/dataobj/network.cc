#include "network.h"

/**
 * Initializes the network core (as that is needed for some platforms
 * @return true if the core has been initialized, false otherwise
 */
bool network_initialize()
{
	return false;
}



// open a socket or give a decent error message
const char *network_open_address( const char *, SOCKET & )
{
	return "Cannot init network!";
}



// if sucessful, starts a server on this port
bool network_init_server( int  )
{
	return false;
}



void network_add_client( SOCKET  )
{
}

static void network_remove_client( SOCKET  )
{
}

// number of currently active clients
int network_get_clients()
{
	return 0;
}


/* do appropriate action for network server:
 * - either connect to a new client
 * - recieve commands
 */
SOCKET network_check_activity(int , char *, int & )
{
	return INVALID_SOCKET;
}



bool network_check_server_connection()
{
	return false;
}




// send data to all clients
void network_send_all(char *, int , bool  )
{
}



// send data to server
void network_send_server(char *, int  )
{
}



const char *network_send_file( SOCKET , const char * )
{
	return "Client closed connection during transfer";
}



const char *network_recieve_file( SOCKET , const char *, const long  )
{
	return "No connection";
}



void network_close_socket( SOCKET  )
{
}



/**
 * Shuts down the network core (since that is needed for some platforms
 */
void network_core_shutdown()
{
}

