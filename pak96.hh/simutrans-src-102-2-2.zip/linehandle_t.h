#ifndef linehandle_t_h
#define linehandle_t_h

#include "tpl/quickstone_tpl.h"

class simline_t;

typedef quickstone_tpl<simline_t> linehandle_t;

#endif
