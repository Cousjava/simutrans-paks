// just some defualt intro and retirement dates, if nothing else is defined

#ifndef DEFAULT_INTRO_DATE

#define DEFAULT_INTRO_DATE (1900)
#define DEFAULT_RETIRE_DATE (2999)

#endif
