<?
	include("include/header.php");?>
	SEM VLOZIT SVUJ KOD
<?
	include("include/footer.php");
?>