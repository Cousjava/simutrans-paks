<?php

include "./obj.inc";

HtmlHead();
Nadpis ("Objects");

echo <<<EOF
<a href="./">SimuTranslator - home</a><p>
<a href="obj_browser.php">OBJECT BROWSER - obj_browser.php</a><p>
<a href="obj_import.php">OBJECT IMPORT - obj_import.php</a><p>
EOF;

HtmlFoot();
?>
