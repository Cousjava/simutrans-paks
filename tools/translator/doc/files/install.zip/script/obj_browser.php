<?php
	include("include/header.php");

include "./include/obj.inc";

HtmlHead();
Nadpis ("Objects - Browser");
Nadpis (htmllink("obj_index.php","back"),1);

db_connect();

define ("table_head", <<<HTML
<table class="top" cellpadding=5 cellspacing=0 border=1>
HTML
);
define ("table_line", <<<HTML
<tr class="top">
%s
</tr>
HTML
);
define ("table_field", <<<HTML
<td class="top">
%s
</td>
HTML
);
define ("table_foot", <<<HTML
</table>
HTML
);

function printobjhead() {
  $row.=sprintf ( table_field, 'obj_name' );
  $row.=sprintf ( table_field, 'version' );
  $row.=sprintf ( table_field, 'obj' );
  $row.=sprintf ( table_field, 'preview' );
  printf ( table_line, $row );
}
function printobj($obj) {
  $link = sprintf ('<a href="obj_browser.php?obj=%s&ver=%s">%s</a>'
    ,$obj['obj_name']
    ,$obj['Version_version_id']
    ,$obj['obj_name']
  );
  $row.=sprintf ( table_field, $link );
  $row.=sprintf ( table_field, $obj['Version_version_id'] );
  $row.=sprintf ( table_field, $obj['obj'] );
  $link = sprintf ('<a href="obj_browser.php?obj=%s&ver=%s">%s</a>'
    ,$obj['obj_name']
    ,$obj['Version_version_id']
    ,sprintf ("<img border=0 src='%s'>","../images/".$obj['image_path'])
  );
  $row.=sprintf ( table_field, $link );
  printf ( table_line, $row );
}

function obj_info ($obj,$ver) {
  echo_n ("");
  Nadpis ("Object details",1);
  if (empty($_GET['obj'])) {
    echo_n ("No object selected.");
    return;
  }
  $sql = sprintf ("SELECT obj_name, Version_version_id, obj, image_path, img_dsc FROM Objects
    where obj_name='%s' and Version_version_id=%s;", $obj, $ver);
  $sql = sprintf ("SELECT obj_name, Version_version_id, obj, image_path, img_dsc FROM Objects
    where obj_name='%s' and Version_version_id=%d;", $_GET['obj'], $_GET['ver']);
//echo $sql;
  $query = mysql_query($sql) or die ("SQL error: ".mysql_error());
  if ($row=mysql_fetch_array($query)) {
    echo table_head;
    $tr="";
    $tr.=sprintf ( table_field, "obj_name" );
    $tr.=sprintf ( table_field, $row['obj_name'] );
    printf ( table_line, $tr ); $tr="";
    $tr.=sprintf ( table_field, "version" );
    $tr.=sprintf ( table_field, $row['Version_version_id'] );
    printf ( table_line, $tr ); $tr="";
    $tr.=sprintf ( table_field, "obj" );
    $tr.=sprintf ( table_field, $row['obj'] );
    printf ( table_line, $tr ); $tr="";
    $tr.=sprintf ( table_field, "image_path" );
    $tr.=sprintf ( table_field, $row['image_path'] );
    printf ( table_line, $tr ); $tr="";

    $tr.=sprintf ( table_field, "img_dsc" );
    $lines = linearray ($row['img_dsc']);
    $img_dsc = sprintf ("<CODE>%s</CODE>",printlines($lines));
    $tr.=sprintf ( table_field, $img_dsc );
    printf ( table_line, $tr ); $tr="";

    $tr.=sprintf ( table_field, "preview" );
    $preview = sprintf ("<img src='%s'>","../images/".$row['image_path']);
    $tr.=sprintf ( table_field, $preview );
    printf ( table_line, $tr ); $tr="";

    $sql = sprintf ("SELECT p_name, p_value FROM Property
      WHERE having_obj_name='%s' and having_Version_version_id=%d
      ORDER BY p_name;"
      ,$row['obj_name']
      ,$row['Version_version_id']
    );
    $query2 = mysql_query($sql) or die ("SQL error: ".mysql_error());
    while ($row2=mysql_fetch_array($query2)) {
      $tr.=sprintf ( table_field, $row2['p_name'] );
      $tr.=sprintf ( table_field, $row2['p_value'] );
      printf ( table_line, $tr ); $tr="";
    }
    mysql_free_result($query2);

    echo table_foot;

  } else {
    echo_err (sprintf("No records for obj_name=%s version=%s"
      ,$obj,$ver
    ));
    echo_n ( sprintf("sql='$sql'<br>mysql_num_rows=%d"
      ,mysql_num_rows($query)
    ));
  }
  mysql_free_result($query);
}

function obj_list () {
  echo_n ("");
  Nadpis ("Object list",1);
  $sql = "SELECT obj_name, Version_version_id, obj, image_path FROM Objects ORDER BY obj_name;";
  $query = mysql_query($sql) or die ("SQL error: ".mysql_error());
  echo table_head;
  printobjhead ();
  while ($row=mysql_fetch_array($query)) {
//echo "XX".$row['obj_name']."XX";
$p=strpos($row['obj_name'],"\n");
    if ($p!==false) echo "xxxxxxxxxxxxxxxx";
    printobj ($row);
  }
  echo table_foot;
  mysql_free_result($query);
}

obj_info ($_GET['obj'],$_GET['ver']);
obj_list ();
     	include("include/footer.php");
HtmlFoot();
?>