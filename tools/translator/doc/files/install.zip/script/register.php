<?php
	/**
		Registrace uzivatele a redirect zpet.
		Svatik, 12.9.04
	*/
	include("include/dblib.php");
	$name = trim($_POST['username']);
	$pass1 = trim($_POST['password']);
	$pass2 = trim($_POST['password2']);
	$back = $_SERVER['HTTP_REFERER'];

	/* nastavi se priznak chybne registrace: */
	$msg = '';
	/* musi byt spravne prihlasovaci jmeno */
	if (is_null($name) || ($name == ''))
		$msg = "bad_username";
	/* i heslo, */
	else if (is_null($pass1) || ($pass1 == ''))
		$msg = "bad_password";
	/* hesla se museji pro jistotu rovnat */
	else if ($pass1 != $pass2)
		$msg = "different_passwords";
	/* a uzivatel nesmi jeste existovat */
	else {
		$user=db_query("SELECT * FROM Users WHERE u_user_id='".$name."' AND password='".$pass1."';");
		if (db_num_rows($user) > 0)
			$msg = "user_exists";
	}

	/* kdyz byla chyba, tak se oznami zpet */
	if ($msg != '')
		Header ("Location: ".urlAppend($back,"msg=".$msg));
	else {
	/* jinak je uzivatel vlozen a zalogovan */
		db_query("INSERT INTO Users (u_user_id, password) VALUES ".
			"('".$name."','".$pass1."');");
		include ("include/login.inc.php");
		login (db_insert_id());
		if (strpos($back, "registerForm") > 0)
			Header ("Location: ./");
		else
			Header ("Location: ".$back);
	}
?>