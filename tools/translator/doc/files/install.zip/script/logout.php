<?php
/**
	Odlogovani uzivatele
	Svatik, 12.9.04
*/
	include ("include/dblib.php");
	$_SESSION["userId"] = null;
	header ("Location: ./");
?>