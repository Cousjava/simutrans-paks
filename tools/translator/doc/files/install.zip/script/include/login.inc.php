<?

/*echo 'login.inc included';*/
	/**
		Funkce souvisejici s logovanim
		Svatik, 16.9.04
	*/


	/**
		Zaloguje uzivatele (nastavi SESSION promenne a popripade COOKIES)
			@param id - id uzivatele
	*/
	function login($id) {
		$_SESSION['userId'] = $id;
	}

?>