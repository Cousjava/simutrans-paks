<?php
	/**
		Login a redirect zpet.
		Svatik, 12.9.04
	*/
	include_once("include/dblib.php");
	$user=db_query("SELECT * FROM Users WHERE u_user_id='".$_POST['username']."' AND password='".$_POST['password']."';");
	if ((!$user) || (db_num_rows($user) == 0)) {
		// kdyz neexistuje, tak nastavim, ze nikdo neni zalogovany
		$_SESSION['userId']=null;
		// preposlu na puvodni stranku + info, ze se nepovedlo
		Header ("Location: ".urlAppend($_SERVER['HTTP_REFERER'], "msg=login_failed"));
	} else {
		// jinak si z databaze nactu jmeno, heslo a prava...
		$info = db_fetch_array($user);
		include ("include/login.inc.php");
		// a zaloguju
		login ($info['u_user_id']);
		// preposlu na puvodni stranku bez zpravy
		Header ("Location: ".ereg_replace("[& | \?]msg=.*", "", $_SERVER['HTTP_REFERER'])."?msg=login_ok");
	}
?>