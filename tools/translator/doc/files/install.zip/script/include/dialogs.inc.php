<?php

/*echo 'dialogs.inc included';*/
        /**
                Funkce pro zobrazeni dialogu na index.php
                Svatik, 10.9.04
        */

        /**
                Zobrazi nadpis dialogu
                        @param title - nadpis
        */
        function showTitle($title) {
			global $ROOT;
		?>
			<h2><?= $title ?></h2>
		<?
        }


        /**
                Podle kodu v URL vrati zpravu
                        @param action - po ktere akci to bylo - 0=login, 1=register
                        @return msg - vrati zpravu pro dialog "login" nebo "register"
        */
        function getMessage($action) {
                switch ($action) {
                        case 0:
                                switch ($_GET['msg']) {
			 case 'login_ok':
				$msg ="prihlasen";
				break;
                                        case 'login_failed':
                                                $msg = "nepovedlo se!";
                                                break;
                                        default:
                                                $msg = "";
                                }
                                break;
                        case 1:
                                switch ($_GET['msg']) {
                                        case 'bad_username':
                                                $msg = "U�iv.jm�no nebylo zad�no!";
                                                break;
                                        case 'bad_password':
                                                $msg = "Heslo nebylo zad�no!";
                                                break;
                                        case 'different_passwords':
                                                $msg = "Hesla se neshoduj�!";
                                                break;
                                        case 'user_exists':
                                                $msg = "Takov� u�ivatel u� existuje!";
                                                break;
                                        default:
                                                $msg = "";
                                }
                                break;
                }
                return $msg;
        }

        /**
                Zobrazi formular pro zalogovani
        */
        function loginForm($title="P�ihl�sit se") {
			global $ROOT;
                ?>
                <div class="indexDialog" id="login">
                <form action="<?= $ROOT ?>login.php" method="post" name="login">
                        <?
                        $msg = getMessage(0);
                        if ($msg != '')
                                echo "<font class='red'>$msg</font>";
                        ?>
                        <table align="center">
                                <tr>
                                        <td align="right">User Name (Id):</td>
                                        <td align="left"><input type="text" name="username"></td>
                                </tr>
                                <tr>
                                        <td align="right">Password:</td>
                                        <td align="left"><input type="password" name="password"></td>
                                </tr>
                                <tr>
                                <td colspan=2>
                                        <button type="submit">Login</button>
                                </td></tr>
                        </table>
                </form>
                </div>
                <?php
        }



        /**
                Zobrazi formular pro odlogovani
                        [@param title] - nadpis
        */
        function logoutForm($title = "U�ivatel p�ihl�en") {
			global $ROOT;
                ?>
                <div class="indexDialog" id="logout">
                <form action="<?= $ROOT ?>logout.php" method="post" name="logout">
                        <? showTitle($title); ?>
                        <button type="submit">Odhl�sit</button>
                </form>
                </div>
                <?php

        }



        /**
                Zobrazi formular pro registraci
                        [@param title] - nadpis
        */
        function registerForm($title = "Registrace") {
			global $ROOT;
                ?>
                <div class="indexDialog" id="register">
                <form action="<?= $ROOT ?>register.php" method="post" name="register">
                        <? showTitle($title);
                        $msg = getMessage(1);
                        if ($msg != '')
                                echo "<font class='red'>$msg</font>";
                        ?>
                        <table align="center">
                                <col align="right">
                                <col align="left">
                                <tr>
                                        <td>Jm�no:</td>
                                        <td><input class="must" type="text" name="username"></td>
                                </tr>
                                <tr>
                                        <td>Heslo:</td>
                                        <td><input class="must" type="password" name="password"></td>
                                </tr>
                                <tr>
                                        <td>Heslo znovu:</td>
                                        <td><input class="must" type="password" name="password2"></td>
                                </tr>
                        </table>
                        <button type="submit">Registrovat</button>
                </form>
                </div>
                <?php
        }

?>