<?php

/*echo 'dlib included';*/
/**
	Knihovna fci pro praci s db
	Zavodnik, 10.6.04
*/

/* pripoji se k databazi */
function db_connect() {

   global $id;
if(date("U") > mktime(12,00,00,4,26,2004))
                {
                        if (! $dbconnect = mysql_pconnect("localhost", "st_appl", "hchkrdtn")) {
                                echo "<h2>Chyba: nelze se p�ipojit k datab�zi!</h2>";
                        }

                        if (! @mysql_select_db("st_translator")) {
                                echo "<h2>Chyba: datab�ze nenalezena!</h2>";
                        }
                        return $dbconnect;
                }
}

/* sql dotaz */
function db_query($query) {
    global $jinedblib;
   //   if (!$jinedblib) echo "<br><font color=gray><small> $query ;</small></font> ";
    return @mysql_query($query);
}

/* nacte vysledek do pole zaznam[cislo] */
function db_fetch_row($queryid) {
        return @mysql_fetch_row($queryid);
}

/* nacte vysledek do pole zaznam[nazev] */
function db_fetch_array($queryid) {
        return @mysql_fetch_array($queryid);
}

/* pocet odpovidajicich zaznamu */
function db_num_rows($queryid) {
        return @mysql_num_rows($queryid);
}

/* pocet ovlivnenych zaznamu pri posledni, insert, update, delete operaci */
function db_affected_rows() {
        return @mysql_affected_rows();
}

/* posune ukazatel resultu na radek */
function db_data_seek($result, $row_number) {
        return @mysql_data_seek($result, $row_number);
}

/* vrati hodnotu posledniho auto increment klice */
function db_insert_id($id = null) {
		if (is_null($id))
			return @mysql_insert_id();
		else return @mysql_insert_id($id);
}

/* vrati hodnotu posledniho erroru pri provadeni mysql prikazu */
function db_error() {
		return @mysql_error();
}

	/**
		Vraci URL s pridanym parametrem na konci
			@param url - zakladni url
			@param appendix - parametr pro pridani
			@return nove_url - url obohacene o parametr appendix
	*/
	function urlAppend ($url, $appendix) {
		return $url.((strpos($url, "?") > 0) ? "&" : "?").$appendix;
	}

session_start();
db_connect();
?>