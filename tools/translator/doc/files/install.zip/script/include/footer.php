<?
/**
	Zapati spolecne pro vsechny stranky
*/
?>



<!-- obecna paticka pro vsechny stranky SimuTranslatoru -->

<p>
<br /><br /><br /><br />
<br />&nbsp;
</p>

<hr />


<p class="ending">
  <br />
  &copy;2004 SimuTranslator Team<br />
  <a href="https://service.felk.cvut.cz/courses/36SI3/prj/36SI342">About SimuTranslator</a>.
  <br />&nbsp;
</p>

<hr />
</body>
</html>
<? die(); ?>