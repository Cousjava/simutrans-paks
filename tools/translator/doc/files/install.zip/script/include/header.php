<?php
	/**
		Hlavicka spolecna pro vsechny stranky
	*/
	require_once ("include/dblib.php");
	require_once ("include/dialogs.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<title><?= $title ?></title>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
<link href="include/style.css" type="text/css" rel="StyleSheet" />
</head>
<body>

<!-- obecna hlavicka pro vsechny stranky simu Translatoru-->
<div class="tableback">
<table class="top" cellspacing="0px" cellpadding="0px">
  <colgroup>
    <col width="20%" />
    <col width="80%"/>
  </colgroup>

  <tr class="top">
    <td class="top" >
        <img src="include/logo_sm.png" alt="SimuTranslator logo" width="200px" height="30px" title="SimuTranslator" />
    </td>


    <td class="top" >


                   <a href="main.php">Go&nbsp;To&nbsp;Main</a>

                   &nbsp;&nbsp;&nbsp;

                   <a href="obj_index.php">Import&nbsp;Objects</a>

                   &nbsp;&nbsp;&nbsp;

                   Upload&nbsp;Texts

                   &nbsp;&nbsp;&nbsp;

                   Edit&nbsp;Texts

                   &nbsp;&nbsp;&nbsp;

                   List&amp;Reseve&nbsp;Texts

                   &nbsp;&nbsp;&nbsp;

                   Download&nbsp;Texts

                   &nbsp;&nbsp;&nbsp;

                   Preferences

                   &nbsp;&nbsp;&nbsp;

                   <?php

                        if (!is_null($_SESSION['userId']))
                        {

                            echo "<a href=\"logout.php\">Logout</a>";

                        } else
                        {
                            echo "<a href=\"index.php\">Log In</a>";
                        }
                   ?>

    </td>
  </tr>
</table>
</div>