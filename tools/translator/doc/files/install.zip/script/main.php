<?
    include("include/header.php");
?>






<h1><?php

    //Am I loogeed as some known user?
    if (!is_null($_SESSION['userId']))
    {
        //If yes
        //querry for real user name
        $real_u_name_q=db_query("SELECT `real_name` FROM `Users` WHERE u_user_id ='" .$_SESSION['userId']."';");

        //paranoid check, this querry should allways fetch one row if DB is oncsistent!
	    if (db_num_rows($real_u_name_q) != 0)
        {
	        //get name
            $real_u_name = db_fetch_row($real_u_name_q);

            //display welcome text
            echo 'Welcome '.$real_u_name[0];
        } else
        {
            //paranoic clause
            echo 'Unknown User';
        }

	} else
	{  //I'm not known user - display general text
	   echo 'Welcome in SimuTranslator!';
	}
?></h1>

    <p>
        &nbsp;   <?php
                 /*
                 if (!is_null($_SESSION['userId']))
                 {
                    echo "Logged as $_SESSION[userId].";
                 } else
                    echo "Unknown user.";
                 */
                 ?>
    </p>


    <h2>You can perform these actions:</h2>


<p class="main">

<?php
//now check for user type and offer allowed actions:

    $user_type = "unknown";

    //Am I loogeed as some known user?
    if (!is_null($_SESSION['userId']))
    {
        //If yes
        //querry for real user role
        $real_u_role_q=db_query("SELECT `role` FROM `Users` WHERE u_user_id ='" .$_SESSION['userId']."';");

        //paranoid check, this querry should allways fetch one row if DB is oncsistent!
	    if (db_num_rows($real_u_role_q) != 0)
        {
	        //get querry result
            $real_u_role = db_fetch_row($real_u_role_q);

            //save new user role
            $user_type = $real_u_role[0];
        }
	}

    ////////////////////////////////////////////////////////////////////////////
    ////Display proper actions//////////////////////////////////////////////////


	if ( $user_type == "admin" )
	 echo "<a href=\"obj_index.php\">Import&nbsp;Objects</a><br />Load object definitions into the database.<br /><br />\n";

	if (( $user_type == "admin" ) || ($user_type == "tr1") || ($user_type == "tr2"))
     echo "<a href=\"load.php\">Upload&nbsp;Texts</a><br />Load the texts you have translated off-line. <br /> <br />\n";

	//available allways - should check the user type on the fly and display proper information
    echo "<a href=\"edit.php\">Edit&nbsp;Texts</a><br />Lunch on-line text editation module.<br /><br />\n";


    if (( $user_type == "admin" ) || ($user_type == "tr1") || ($user_type == "tr2"))
     echo "<a href=\"lister.php\">List&amp;Reseve&nbsp;Texts</a><br />List the exisitng texts, browse them, reserve them. <br /><br />\n";


    //available allways
    echo "<a href=\"wrap.php\">Download&nbsp;Texts</a><br />Download text files for Simutrans or<br /> texts for off-line translation.<br /><br />\n";


    if (( $user_type == "admin" ) || ($user_type == "tr1") || ($user_type == "tr2"))
     echo "<a href=\"preferences.php\">Preferences</a><br />Set your prefferences.<br /><br />\n";

    if ( $user_type == "admin" )
     echo "<a href=\"admin.php\">Modify User</a><br />Administration interface.<br /><br />\n";




    if (!is_null($_SESSION['userId']))
    {
        echo "<a href=\"logout.php\">Logout " . $_SESSION['userId'] . "</a><br />\n";
        echo "Leave the SimuTranslator.<br />\n";

    } else
    {
        echo "<a href=\"index.php\">Log In</a><br />\n";
        echo "Log to SimuTranslator!\n" ;
    }

?>




</p>





<?
    /*logoutForm();*/
	include("include/footer.php");
?>