<?php

include("include/header.php");

$prefix="";
$spacer=0;
$default_tab="   ";

$user="Translator1"; //Translator1,Napik

echo_b("<pre>");
print_r($_POST);
echo_e("</pre>");

echo_c("<div><user = $user</div>");

function echo_b($string)
{
 global $spacer,$prefix,$default_tab;
 echo($prefix.$string."\n");
 $spacer++;
 $prefix.=$default_tab;
}

function echo_e($string)
{
 global $spacer,$prefix,$default_tab;
 $spacer--;
 $prefix="";
 for($i=0;$i<$spacer;$i++)
    $prefix.=$default_tab;
 echo($prefix.$string."\n");
}

function echo_c($string)
{
 global $prefix;
 echo($prefix.$string."\n");
}

/*
function db_connect()
{
 $db=mysql_connect("localhost","st_appl","hchkrdtn") or die('I cannot connect to the database because: ' . mysql_error());
 mysql_select_db("st_translator");
} */

function get_next()
{
 global $index,$objects;
 $last=count($objects)-1;
 $i=$index;
 if ($i==$last) $i=0; else $i++;
 return $i;
}

function get_prev()
{
 global $index,$objects;
 $last=count($objects)-1;
 $i=$index;
 if ($i==0) $i=$last; else $i--;
 return $i;
}

function gen_object()
{
 echo_b("<div id=\"id_object\">");
 echo_b("<div id=\"id_object_header\">");
 gen_prev();
 gen_next();
 gen_goto();
 echo_e("</div>");
 echo_b("<div id=\"id_object_body\">");
 echo_b("<div id=\"id_object_left\">");
 gen_name();
 gen_attr();
 echo_e("</div>");
 gen_img();
 echo_e("</div>");
 echo_e("</div>");
}

function gen_prev()
{
 global $objects;
 $prev=$objects[get_prev()];
 echo_b("<form id=\"id_prev\" method=\"post\" action=\"edit.php\">");
 echo_c("<input type=\"HIDDEN\" name=\"index\" value=\"".get_prev()."\"/>");
 echo_c("<input type=\"submit\" name=\"submit_prev\" value=\"PREV\" title=\"".$prev->obj_name."\"/>");
 echo_c("<div><label>".$prev->obj_name."</label></div>");
 echo_e("</form>");
}

function gen_next()
{
 global $objects;
 $next=$objects[get_next()];
 echo_b("<form id=\"id_next\" method=\"post\" action=\"edit.php\">");
 echo_c("<input type=\"HIDDEN\" name=\"index\" value=\"".get_next()."\"/>");
 echo_c("<input type=\"submit\" name=\"submit_next\" value=\"NEXT\" title=\"".$next->obj_name."\"/>");
 echo_c("<div><label>".$next->obj_name."</label></div>");
 echo_e("</form>");
}

function gen_goto()
{
 echo_b("<form id=\"id_goto\" method=\"post\" action=\"edit.php\">");
 echo_c("<input type=\"text\" size=\"25\" name=\"txt_goto\">");
 echo_c("<input type=\"submit\" name=\"submit_goto\" value=\"Go To\">");
 echo_e("</form>");
}

function gen_img()
{
 global $object;
 echo_b("<div id=\"id_img\">");
 echo_b("<div>");
 echo_c("<img src=\"../images/".$object->image_path."\" alt=\"object_image\" align=\"right\" valign=\"bottom\"/>");
 echo_e("</div>");
 echo_c("<div><h6>".$object->img_dsc."</h6></div>");
 echo_e("</div>");
}

function gen_attr()
{
 global $object;
 echo_b("<div>");
 echo_c("<label for=\"id_attr\"><bold>Attributes :</bold></label>");
 echo_e("</div>");
 echo_b("<table id=\"id_attr\" border=\"1\">");
 echo_b("<tr>");
 echo_c("<th>Name</th>");
 echo_c("<th>Value</th>");
 echo_e("</tr>");
 $query="SELECT * FROM Property p where p.having_obj_name='".$object->obj_name."' and p.having_Version_version_id=".$object->Version_version_id;
 $result = mysql_query($query) or die("SQL error : " . mysql_error());
 $i=0;
 while($row=mysql_fetch_object($result))
 {
  echo_b("<tr>");
  echo_c("<td>".$row->p_name."</td>");
  echo_c("<td>".$row->p_value."</td>");
  echo_e("</tr>");
 }
 mysql_free_result($result);
 echo_e("</table>");
}

function gen_name()
{
 global $object;
 echo_b("<h1 id=\"id_name\">");
 echo_c($object->obj_name);
 echo_e("</h1>");
}

function gen_translate($lang_id)
{
	global $object;
 	echo_b("<div class=\"id_translate\">");
 	$query="SELECT * FROM Translations WHERE Object_obj_name='".
    	$object->obj_name.
    	"' AND Object_Version_version_id=".
        $object->Version_version_id.
        " AND language_language_id='".
        $lang_id.
        "'";
 	$result = mysql_query($query) or die("SQL error : " . mysql_error());
 	echo_b("<div class=\"leftedit\">");
 	if ($row=mysql_fetch_object($result))
 	{
		if ($row->tr_text=="")
			$tr_text_label="<div class=\"red\">empty</div>";
		else
			$tr_text_label="<div>".$row->tr_text."</div>";
    	$tr_text=$row->tr_text;

		if ($row->suggestion=="")
			$suggestion_label="<div class=\"red\">empty</div>";
		else
    		$suggestion_label="<div>".$row->suggestion."</div>";
    	$suggestion=$row->suggestion;
 	}
 	else
 	{
		$tr_text_label="<div class=\"red\">empty</div>";
		$suggestion_label="<div class=\"red\">empty</div>";
 	}
 	echo_c("<div><u>Current translation :</u></div>");
 	echo_c($tr_text_label);
 	echo_c("<div><u>Current suggestion :</u></div>");
 	echo_c($suggestion_label);
 	echo_c("<textarea name=\"suggestion_$lang_id\" cols=\"50\" rows=\"1\">".
    	$suggestion.
        "</textarea>"
  	);
  	echo_b("<div>");
  	echo_c("<input type=\"submit\" name=\"submit_suggestion_$lang_id\" value=\"Submit\"/>");
  	echo_e("</div>");
  	echo_c("<textarea name=\"trtext_$lang_id\" cols=\"50\" rows=\"5\">".
    	$tr_text.
    	"</textarea>"
	);
	echo_b("<div>");
  	echo_c("<input type=\"submit\" name=\"submit_trtext_$lang_id\" value=\"Submit\"/>");
  	echo_e("</div>");
	echo_e("</div>");
 	echo_e("</div>");
 	mysql_free_result($result);
}

function gen_all()
{
 global $user,$index;
 gen_object();
 $query="SELECT * FROM Translate WHERE translator_user_id='".$user."'";
 $result = mysql_query($query) or die("SQL error : " . mysql_error());
 echo_b("<form id=\"id_translate_root\" method=\"post\" action=\"edit.php\">");
 echo_c("<input type=\"HIDDEN\" name=\"index\" value=\"$index\"/>");
 while ($row=mysql_fetch_object($result))
 {
  gen_translate($row->lng_tr_language_id);
 }
 echo_b("<div align=\"center\">");
 echo_c("<input type=\"submit\" name=\"submit_all\" value=\"Submit All\"/>");
 echo_e("</div>");
 echo_e("</form>");
 mysql_free_result($result);
}

function translations_exist($lang_id)
{
 global $objects,$index;
 $query="SELECT count(*) FROM Translations WHERE Object_obj_name='".
        $objects[$index]->obj_name.
        "' AND Object_Version_version_id=".
        $objects[$index]->Version_version_id.
        " AND language_language_id='".
        $lang_id.
        "'";
 $result = mysql_query($query) or die("SQL error : " . mysql_error());
 $row=mysql_fetch_object($result);
 mysql_free_result($result);
 return $row;
}

function create_empty_translations($lang_id)
{
 global $objects,$index,$user;
 $query="INSERT INTO Translations (Object_obj_name, Object_Version_version_id, Language_language_id, author_user_id)".
        "VALUES (".
        "'".$objects[$index]->Object_obj_name."',".
        "'".$objects[$index]->Object_Version_version_id."',".
        "'".$objects[$index]->language_language_id."',".
        "'".$user."')";
 $result = mysql_query($query) or die("SQL error : " . mysql_error());
 mysql_free_result($result);
}

function update_translations($lang_id,$field,$value)
{
	global $objects,$index,$user;
	$query="UPDATE Translations SET $field = '$value' WHERE Object_obj_name='".
    	$objects[$index]->obj_name.
        "' AND Object_Version_version_id=".
        $objects[$index]->Version_version_id.
        " AND language_language_id='".
        $lang_id.
        "'";
	$result = mysql_query($query) or die("SQL error : " . mysql_error());
}

function update_translations2($lang_id,$field0,$value0,$field1,$value1)
{
	global $objects,$index,$user;
	$query="UPDATE Translations SET $field0 = '$value0',$field1 = '$value1' WHERE Object_obj_name='".
    	$objects[$index]->obj_name.
        "' AND Object_Version_version_id=".
        $objects[$index]->Version_version_id.
        " AND language_language_id='".
        $lang_id.
        "'";
	$result = mysql_query($query) or die("SQL error : " . mysql_error());
}

function do_start()
{
	global $objects,$index,$object,$HTTP_POST_VARS;
 	db_connect();
 	$query="SELECT * FROM Objects order by obj_name";
 	$result = mysql_query($query) or die("SQL error : " . mysql_error());
 	$i=0;
 	while ($row=mysql_fetch_object($result))
    	$objects[$i++]=$row;
 	mysql_free_result($result);
 	$index=(integer)0;
 	reset($HTTP_POST_VARS);
 	while(list($key,$value) = each($HTTP_POST_VARS))
 	{
		if (substr($key,0,7)=="submit_")
		{
			$action=substr($key,7);
			$acts=explode("_",$action);
			$action=$acts[0];
			break;
		}
 	}
 	$index=(integer)$HTTP_POST_VARS["index"];
 	switch($action)
 	{
		case "all":
			reset($HTTP_POST_VARS);
			$lang_index=(integer)0;
		 	while(list($key,$value) = each($HTTP_POST_VARS))
 			{
				if (substr($key,0,7)=="trtext_")
				{
					$_lang[$lang_index++]=substr($key,7);
					$_tr_text[substr($key,7)]=$value;
				}
				if (substr($key,0,11)=="suggestion_")
				{
					$_suggestion[substr($key,11)]=$value;
				}
			}
			for($i=0;$i<count($_lang);$i++)
 			{
				$lng=$_lang[$i];
				if (translations_exist($lng)=="0")
		        	create_empty_translations($lng);
		    	update_translations2($lng,"tr_text",$_tr_text[$lng],"suggestion",$_suggestion[$lng]);
			}
	    	break;
		case "goto":
       		$query="SELECT * FROM Objects where obj_name='".$HTTP_POST_VARS["txt_goto"]."'";
       		$result = mysql_query($query) or die("SQL error : " . mysql_error());
       		if ($row=mysql_fetch_object($result))
       		{
        		for($index=0;$index<count($objects);$index++)
        		{
          			$object=$objects[$index];
          			if ($object->obj_name==$HTTP_POST_VARS["txt_goto"])
          			{
              			$found="true";
              			break;
          			}
        		}
        		if ($found!="true") $index=(integer)$HTTP_POST_VARS["index"];
       		}
			mysql_free_result($result);
       		break;
		case "suggestion":
			$lng=substr($key,strlen("submit_suggestion_"));
       		if (translations_exist($lng)=="0")
		        create_empty_translations($lng);
			update_translations($lng,"suggestion",$HTTP_POST_VARS["suggestion_".$lng]);
       		break;
  		case "trtext":
			$lng=substr($key,strlen("submit_trtext_"));
       		if (translations_exist($lng)=="0")
		        create_empty_translations($lng);
		    update_translations($lng,"tr_text",$HTTP_POST_VARS["trtext_".$lng]);
       		break;
	}
	$object=$objects[$index];
	gen_all();
}

function do_finish()
{
 mysql_close($db);
}


do_start();
/*
 $query="SELECT * FROM Translate WHERE translator_user_id='".$user."'";
 echo("MAIN QUERY : $query<br/>");
 $result = mysql_query($query) or die("SQL error : " . mysql_error());
 $i=0;
 while($row=mysql_fetch_object($result))
 {
  print_r($row);
  echo("<br/>");
 }
 mysql_free_result($result);
*/

	include("include/footer.php");
?>
