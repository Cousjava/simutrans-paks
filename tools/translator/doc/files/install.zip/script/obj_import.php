<?php

	include("include/header.php");
include "./include/obj.inc";
include "./include/obj_import.inc";

HtmlHead();
Nadpis ("Objects - Import");
Nadpis (htmllink("obj_index.php","back"),1);

db_connect();

/////////// DBG ///////////
if ($_SERVER['SERVER_NAME']==svatej) {
  echo_n ('M:\fel\si3\data\tree_example.zip');
  echo_n ('M:\fel\si3\data\objects_sm.zip');
  echo_n ('M:\fel\si3\data\rail_signals.zip');
  echo_n ('M:\fel\si3\data\objects-test.zip');
}

printf (<<<EOF
<form enctype="multipart/form-data" action="obj_import.php" method="POST">
 Select version:
 <select name="version">
  %s</select><BR>
 Select file:
 <input type="file" id="uploadfile" name="uploadfile" size="50" value="tree_example.zip">
 <input type="submit">
</form>

<script language="JavaScript" type="text/javascript">
</script>
<br>

EOF
  ,return_versions_html()
);

if (!empty($_FILES['uploadfile']['name']))
{
  echo_n ("upload: ".$_FILES['uploadfile']['name']);
  echo_n ("size: ".$_FILES['uploadfile']['size']);
//  print_r($_FILES);
  $extdir=$st_home."/tmp/zip";
  if (is_dir($extdir)) system ("rm -r ".$extdir." 2>&1");
  system ("mkdir ".$extdir);
  import_zip ();
  echo "<HR>";
  echo_n ("Import finished.");
} else {
  $extdir=$st_home."/tmp/zip";
if (1) {
  if (is_dir($extdir)) {
    echo_n ("Removing unzipped files...");
    system ("rm -r ".$extdir." 2>&1");
  }
} else {
  echo_n ("[DBG] Processing old unzipped data...");
  browsedir($extdir,$filecount,$files,".*.dat");
  for ($i=1;$i<=$filecount;$i++) {
    import_dat($files[$i]);
  }
  echo "<HR>";
  echo_n ("Import finished.");
}
}
include("include/footer.php");
HtmlFoot();
?>