<?php
	include("include/header.php");
include "./include/obj.inc";

HtmlHead();
Nadpis ("Objects");

echo <<<EOF
<p>
<a href="obj_browser.php">OBJECT BROWSER - obj_browser.php</a><br /><br />
<a href="obj_import.php">OBJECT IMPORT - obj_import.php</a><br /><br />
</p>
EOF;


include("include/footer.php");
HtmlFoot();
?>