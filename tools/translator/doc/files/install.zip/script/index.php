<?php
	/**

	*/
	require ("./include/dblib.php");
	if (is_null($_SESSION['userId']))
    {

		include_once("./include/header.php");


		echo '<h1 class=\"pagename\">Log In</h1>';


		loginForm();


?>

<p>
<br /> &nbsp; <br />
If you want to seriously help to translate Simutrans, you need to register. Please contact Tom� Kube� to do so.<br />
If you are just looking for new uptodate game texts, or are just curious browser, you can proceed unlogged (your actions will be restricted).
</p>

<?php

	/*	registerForm();  */
	} else
	 Header("Location: ./main.php");


	include_once("./include/footer.php");
?>