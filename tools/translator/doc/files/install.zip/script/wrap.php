<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
	<title>Wrapper</title>
	<link rel="stylesheet" type="text/css" href="/include/style.css"/>
	<link rel="stylesheet" type="text/css" href="../images/wrap.css"/>
</head>
<body>
<?php

/*mb_internal_encoding("UTF-8");*/

$prefix="";
$spacer=0;
$default_tab="   ";
$user="Translator1"; //Translator1,Napik

function db_connect()
{
	$dbh=mysql_connect("localhost","st_appl","hchkrdtn") or die('I cannot connect to the database because: ' . mysql_error());
	mysql_select_db("st_translator");
}

function echo_b($string)
{
	global $spacer,$prefix,$default_tab;
	echo($prefix.$string."\n");
	$spacer++;
	$prefix.=$default_tab;
}

function echo_e($string)
{
	global $spacer,$prefix,$default_tab;
	$spacer--;
	$prefix="";
	for($i=0;$i<$spacer;$i++)
    $prefix.=$default_tab;
	echo($prefix.$string."\n");
}

function echo_c($string)
{
	global $prefix;
	echo($prefix.$string."\n");
}

function do_header_line($text)
{
	return ("#".str_pad($text,78," ",STR_PAD_BOTH)."#\n");
}

function do_header($texts_translated)
{
	global $user,$lang_id,$version_id;
	$query="SELECT * FROM Users WHERE u_user_id='$user'";
    $result = mysql_query($query) or die("SQL error : " . mysql_error());
    $u=mysql_fetch_object($result);
	mysql_free_result($result);
	$query="SELECT * FROM Languages WHERE language_id='$lang_id'";
    $result = mysql_query($query) or die("SQL error : " . mysql_error());
    $l=mysql_fetch_object($result);
	mysql_free_result($result);
	$query="SELECT * FROM Versions WHERE version_id='$version_id'";
    $result = mysql_query($query) or die("SQL error : " . mysql_error());
    $v=mysql_fetch_object($result);
	mysql_free_result($result);

	return 	"################################################################################\n".
			"#                                                                              #\n".
			"#                Simutrans Scenario Specific Translation File                  #\n".
			do_header_line("Scenario: $v->v_name").
			do_header_line("Language: $l->language_id $l->language_name").
			do_header_line("Encoding: ").
			do_header_line("Fonts : $l->font1 $l->font2").
			do_header_line("Date Created: ".date("j.m Y")).
			"#                                                                              #\n".
			"#                                   authors:                                   #\n".
			do_header_line($u->real_name." ".$u->u_user_id).
			do_header_line("$u->email, $u->note, Text translated: $texts_translated").
			"#                                                                              #\n".
			"################################################################################\n";
}

function get_word_size($_word,$_char_size)
{
 $_size=0;
 for($_i=0;$_i<strlen($_word);$_i++)
  $_size+=$_char_size[substr($_word,$_i,1)];
 return $_size;
}

function startwith($text,$prefix)
{
	if ($prefix==substr($text,0,strlen($prefix))) return 1;
	return 0;
}

function load_font_info()
{
	global $char_size,$space_size,$lang_id,$ShortLineLen,$LongLineLen,$ShortLineCount;
	$query="SELECT * FROM Languages WHERE language_id='$lang_id'";
    $result = mysql_query($query) or die("SQL error : " . mysql_error());
    $l=mysql_fetch_object($result);
	$font_file=explode("\n",$l->f_desc);
	// parse font file
	// sections
	// 0 ... undefined
	// 1 ... constants
	// 2 ... letters
	$section=0;
	for($i=0;$i<count($font_file);$i++)
	{
		$line=$font_file[$i];
		$first_char=substr($line,0,1);
		if ($first_char=="#") continue;
    	if (startwith($line,"[Constants]")==1)
    	{
     		$section=1;
     		continue;
    	}
    	if (startwith($line,"[Letters]")==1)
    	{
     		$section=2;
			continue;
    	}
       	$value=(integer)trim(substr($line,strpos($line,"=")+1));
        switch($section)
        {
	    	case 1:
	    		if (startwith($line,"ShortLineLen")==1)
				{
					$ShortLineLen=$value;
					break;
				}
				if (startwith($line,"LongLineLen")==1)
				{
					$LongLineLen=$value;
					break;
				}
				if (startwith($line,"ShortLineCount")==1)
				    $ShortLineCount=$value;
               	break;
           	case 2:
				$char_size[$first_char]=$value;
       	}
	}
	$space_size=(integer)$char_size[" "];
}

function wrap_line($line)
{
	global $char_size,$space_size,$ShortLineLen,$LongLineLen,$ShortLineCount;
	// PROCESS ONE LINE
    $words=explode(" ",$line);
    $result="";
    $line_size=0;
    $sl_count=0;
    $max_line_size=$ShortLineLen;
    for($i=0;$i<count($words);$i++)
    {
    	// PROCESS ONE WORD
    	$word=$words[$i];
    	$word_size=get_word_size($word,$char_size);
    	if ($line_size+$word_size>$max_line_size)
    	{
    		if (++$sl_count==$ShortLineCount) $max_line_size=$LongLineLen;
    		$result.="\\n".$word;
    		$line_size=$word_size;
     	}
     	else
     	{
      		$result.=$word;
      		$line_size+=$word_size;
     	}
     	if ($line_size+$space_size>$max_line_size)
     	{
    		if (++$sl_count==$ShortLineCount) $max_line_size=$LongLineLen;
      		$result.="\\n";
      		$line_size=0;
     	}
     	else
     	{
      		$result.=" ";
      		$line_size+=$space_size;
     	}
    }
    return $result;
}

db_connect();
if ($_POST["submit"]=="Submit All")
{
	$lang_id=$_POST["language"];
	$version_id=$_POST["version"];
	$choice=$_POST["choice"];

	$query="SELECT count(*) FROM Translations WHERE Language_language_id='$lang_id' AND Object_Version_version_id='$version_id' ORDER BY Object_obj_name";
    $result = mysql_query($query) or die("SQL error : " . mysql_error());
	$row=mysql_fetch_row($result);
	mysql_free_result($result);

	$res=do_header($row[0]);
	load_font_info();

	$query=	"SELECT Object_obj_name,obj_name,Version_version_id,obj,language_language_id,tr_text ".
			"FROM Translations t,Objects o WHERE ".
			"Language_language_id='$lang_id' AND ".
			"Object_Version_version_id='$version_id' AND ".
			"t.Object_obj_name=o.obj_name ".
			"ORDER BY obj,obj_name";
    $result = mysql_query($query) or die("SQL error : " . mysql_error());
	while($row=mysql_fetch_object($result))
	{
		if ($obj!=$row->obj)
		{
			$obj=$row->obj;
			$res.=str_repeat("#".str_pad($row->obj,79,"_",STR_PAD_BOTH)."\n",2);
		}
		$res.=$row->obj_name."\n";
		if ($row->obj=="building"||$row->obj=="tree")
		    $res.=wrap_line($row->tr_text)."\n";
		else
			$res.=$row->tr_text."\n";
	}
	mysql_free_result($result);
	if ($choice=="screen")
		echo_c("<pre>$res</pre>");
	else
	{
		$fp=fopen("/home/st/public_html/tmp/$lang_id.tab","wb");
		fwrite($fp,$res);
		fclose($fp);
		echo_c("<a href=\"../tmp/$lang_id.tab\">Get the file now !</a>");
	}
}
else
{
	echo_b("<form id=\"id_main\" method=\"post\" action=\"wrap.php\">");

	echo_b("<div>Select language :</div>");
	echo_b("<select name=\"language\">");
	$query = "SELECT language_id,language_name from Languages";
	$result = mysql_query($query) or die("SQL error : " . mysql_error());
	while ($row=mysql_fetch_object($result))
	{
		echo_c("<option value=\"$row->language_id\">$row->language_name</option>");
	}
	mysql_free_result($result);
	echo_e("</select>");
	echo_e("</div>");

	echo_c("<div>Select version :</div>");
	echo_b("<select name=\"version\">");
	$query = "SELECT v_name,version_id from Versions";
	$result = mysql_query($query) or die("SQL error : " . mysql_error());
	while ($row=mysql_fetch_object($result))
	{
		echo_c("<option value=\"$row->version_id\">$row->v_name</option>");
	}
	mysql_free_result($result);
	echo_e("</select>");

	echo_b("<div>");
	echo_c("<div>Select output type :</div>");
	echo_c("<input type=\"radio\" name=\"choice\" value=\"file\">To File</input>");
	echo_c("<input type=\"radio\" checked=\"true\" name=\"choice\" value=\"screen\">To Screen</input>");
	echo_e("</div>");

	echo_c("<div><input type=\"submit\" name=\"submit\" value=\"Submit All\"></div>");

	echo_e("</form>");
}
?>
</body>
</html>