<?php

    //will be prefixed by "SimuTranslator - " for window title
	$title = "pagename";

	//list of all user typs allowed on this page
	//header will block access for all other users
    $minimal_user_level=array('guest','tr1','tr2','admin','gu','painter');

    //header, please no output before this (sends header information)
    //establishes the connection to the db, include dblib
	require_once ("include/header.php");

    //prints page title
    //called separately in case you have some special requirements
	PrintTitle();


?>

	<!-- Insert code here. -->

<?php

    //footer, nothing ater this (closes the page)
	include_once ("include/footer.php");
?>